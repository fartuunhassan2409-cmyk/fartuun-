Lucky Cafe Order - Visual Studio C# Windows Forms Project

Requirements:
- Windows
- Visual Studio 2022 with the .NET desktop development workload
- .NET 8 SDK

How to open:
1. Extract the ZIP file.
2. Open LuckyCafeOrder.csproj in Visual Studio.
3. Press F5 or click Start to run.

The project follows the supplied assignment structure:
- One form only
- Customer name, drink selection, quantity, student discount
- Calculate order and lucky number
- Display results in a ListBox
- Save to orders.txt and load from orders.txt
- Clear the form

The orders.txt file is created in the application's working directory when Save to File is used.
