namespace LuckyCafeOrder;

partial class Form1
{
    private System.ComponentModel.IContainer components = null;
    private Label lblTitle;
    private GroupBox grpCustomer;
    private Label lblCustomerName;
    private TextBox txtCustomerName;
    private GroupBox grpDrinkType;
    private RadioButton rdoTea;
    private RadioButton rdoCoffee;
    private RadioButton rdoJuice;
    private Label lblQuantity;
    private TextBox txtQuantity;
    private CheckBox chkStudentMember;
    private GroupBox grpOrderList;
    private ListBox lstOrder;
    private Button btnCalculate;
    private Button btnSave;
    private Button btnLoad;
    private Button btnClear;
    private Label lblTotalPrice;
    private Label lblLuckyMessage;

    protected override void Dispose(bool disposing)
    {
        if (disposing && (components != null))
            components.Dispose();
        base.Dispose(disposing);
    }

    private void InitializeComponent()
    {
        lblTitle = new Label();
        grpCustomer = new GroupBox();
        lblCustomerName = new Label();
        txtCustomerName = new TextBox();
        grpDrinkType = new GroupBox();
        rdoTea = new RadioButton();
        rdoCoffee = new RadioButton();
        rdoJuice = new RadioButton();
        lblQuantity = new Label();
        txtQuantity = new TextBox();
        chkStudentMember = new CheckBox();
        grpOrderList = new GroupBox();
        lstOrder = new ListBox();
        btnCalculate = new Button();
        btnSave = new Button();
        btnLoad = new Button();
        btnClear = new Button();
        lblTotalPrice = new Label();
        lblLuckyMessage = new Label();
        grpCustomer.SuspendLayout();
        grpDrinkType.SuspendLayout();
        grpOrderList.SuspendLayout();
        SuspendLayout();

        // Form
        AutoScaleDimensions = new SizeF(7F, 15F);
        AutoScaleMode = AutoScaleMode.Font;
        BackColor = Color.FromArgb(242, 242, 242);
        ClientSize = new Size(1000, 650);
        MinimumSize = new Size(850, 600);
        StartPosition = FormStartPosition.CenterScreen;
        Text = "Lucky Cafe Order";

        // Title
        lblTitle.AutoSize = true;
        lblTitle.Font = new Font("Segoe UI", 18F, FontStyle.Bold);
        lblTitle.ForeColor = Color.FromArgb(42, 83, 125);
        lblTitle.Location = new Point(25, 18);
        lblTitle.Text = "Lucky Cafe Order";

        // Customer information
        grpCustomer.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
        grpCustomer.Location = new Point(25, 75);
        grpCustomer.Size = new Size(420, 330);
        grpCustomer.Text = "Customer Information";

        lblCustomerName.AutoSize = true;
        lblCustomerName.Font = new Font("Segoe UI", 9F);
        lblCustomerName.Location = new Point(20, 35);
        lblCustomerName.Text = "Customer Name:";

        txtCustomerName.Font = new Font("Segoe UI", 10F);
        txtCustomerName.Location = new Point(20, 60);
        txtCustomerName.Size = new Size(375, 25);

        grpDrinkType.Location = new Point(20, 105);
        grpDrinkType.Size = new Size(375, 125);
        grpDrinkType.Text = "Drink Type";

        rdoTea.AutoSize = true;
        rdoTea.Font = new Font("Segoe UI", 9F);
        rdoTea.Location = new Point(18, 25);
        rdoTea.Text = "Tea ($1)";

        rdoCoffee.AutoSize = true;
        rdoCoffee.Font = new Font("Segoe UI", 9F);
        rdoCoffee.Location = new Point(18, 55);
        rdoCoffee.Text = "Coffee ($2)";

        rdoJuice.AutoSize = true;
        rdoJuice.Font = new Font("Segoe UI", 9F);
        rdoJuice.Location = new Point(18, 85);
        rdoJuice.Text = "Juice ($3)";

        lblQuantity.AutoSize = true;
        lblQuantity.Font = new Font("Segoe UI", 9F);
        lblQuantity.Location = new Point(20, 255);
        lblQuantity.Text = "Quantity:";

        txtQuantity.Font = new Font("Segoe UI", 10F);
        txtQuantity.Location = new Point(95, 250);
        txtQuantity.Size = new Size(75, 25);

        chkStudentMember.AutoSize = true;
        chkStudentMember.Font = new Font("Segoe UI", 9F);
        chkStudentMember.Location = new Point(190, 253);
        chkStudentMember.Text = "Student Member (10% Off)";

        grpCustomer.Controls.Add(lblCustomerName);
        grpCustomer.Controls.Add(txtCustomerName);
        grpCustomer.Controls.Add(grpDrinkType);
        grpCustomer.Controls.Add(lblQuantity);
        grpCustomer.Controls.Add(txtQuantity);
        grpCustomer.Controls.Add(chkStudentMember);

        grpDrinkType.Controls.Add(rdoTea);
        grpDrinkType.Controls.Add(rdoCoffee);
        grpDrinkType.Controls.Add(rdoJuice);

        // Order list
        grpOrderList.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
        grpOrderList.Location = new Point(465, 75);
        grpOrderList.Size = new Size(510, 330);
        grpOrderList.Text = "Order List";

        lstOrder.Font = new Font("Segoe UI", 10F);
        lstOrder.FormattingEnabled = true;
        lstOrder.ItemHeight = 22;
        lstOrder.Location = new Point(15, 25);
        lstOrder.Size = new Size(480, 284);
        grpOrderList.Controls.Add(lstOrder);

        // Buttons
        btnCalculate.Location = new Point(25, 425);
        btnCalculate.Size = new Size(225, 48);
        btnCalculate.Text = "Calculate Order";
        btnCalculate.UseVisualStyleBackColor = true;
        btnCalculate.Click += btnCalculate_Click;

        btnSave.Location = new Point(270, 425);
        btnSave.Size = new Size(225, 48);
        btnSave.Text = "Save to File";
        btnSave.UseVisualStyleBackColor = true;
        btnSave.Click += btnSave_Click;

        btnLoad.Location = new Point(515, 425);
        btnLoad.Size = new Size(225, 48);
        btnLoad.Text = "Load from File";
        btnLoad.UseVisualStyleBackColor = true;
        btnLoad.Click += btnLoad_Click;

        btnClear.Location = new Point(760, 425);
        btnClear.Size = new Size(215, 48);
        btnClear.Text = "Clear";
        btnClear.UseVisualStyleBackColor = true;
        btnClear.Click += btnClear_Click;

        // Result labels
        lblTotalPrice.AutoSize = false;
        lblTotalPrice.BackColor = Color.White;
        lblTotalPrice.BorderStyle = BorderStyle.FixedSingle;
        lblTotalPrice.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
        lblTotalPrice.ForeColor = Color.FromArgb(42, 83, 125);
        lblTotalPrice.Location = new Point(25, 495);
        lblTotalPrice.Size = new Size(950, 45);
        lblTotalPrice.Text = "Total Price:";
        lblTotalPrice.TextAlign = ContentAlignment.MiddleLeft;
        lblTotalPrice.Padding = new Padding(10, 0, 0, 0);

        lblLuckyMessage.AutoSize = false;
        lblLuckyMessage.BackColor = Color.White;
        lblLuckyMessage.BorderStyle = BorderStyle.FixedSingle;
        lblLuckyMessage.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
        lblLuckyMessage.ForeColor = Color.DarkGoldenrod;
        lblLuckyMessage.Location = new Point(25, 545);
        lblLuckyMessage.Size = new Size(950, 45);
        lblLuckyMessage.Text = "Lucky Message:";
        lblLuckyMessage.TextAlign = ContentAlignment.MiddleLeft;
        lblLuckyMessage.Padding = new Padding(10, 0, 0, 0);

        Controls.Add(lblTitle);
        Controls.Add(grpCustomer);
        Controls.Add(grpOrderList);
        Controls.Add(btnCalculate);
        Controls.Add(btnSave);
        Controls.Add(btnLoad);
        Controls.Add(btnClear);
        Controls.Add(lblTotalPrice);
        Controls.Add(lblLuckyMessage);

        grpCustomer.ResumeLayout(false);
        grpCustomer.PerformLayout();
        grpDrinkType.ResumeLayout(false);
        grpDrinkType.PerformLayout();
        grpOrderList.ResumeLayout(false);
        ResumeLayout(false);
        PerformLayout();
    }
}
