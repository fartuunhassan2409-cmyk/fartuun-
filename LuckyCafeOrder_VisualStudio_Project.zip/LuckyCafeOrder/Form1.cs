using System;
using System.IO;
using System.Windows.Forms;

namespace LuckyCafeOrder;

public partial class Form1 : Form
{
    private readonly Random random = new Random();
    private decimal totalPrice = 0m;

    public Form1()
    {
        InitializeComponent();
    }

    private void btnCalculate_Click(object sender, EventArgs e)
    {
        string customerName = txtCustomerName.Text.Trim();

        if (string.IsNullOrWhiteSpace(customerName))
        {
            MessageBox.Show("Please enter the customer name.", "Input Error",
                MessageBoxButtons.OK, MessageBoxIcon.Error);
            return;
        }

        if (!int.TryParse(txtQuantity.Text.Trim(), out int quantity) || quantity < 1)
        {
            MessageBox.Show("Please enter a valid quantity (minimum 1).", "Input Error",
                MessageBoxButtons.OK, MessageBoxIcon.Error);
            return;
        }

        string drinkName;
        decimal drinkPrice;

        if (rdoTea.Checked)
        {
            drinkName = "Tea";
            drinkPrice = 1m;
        }
        else if (rdoCoffee.Checked)
        {
            drinkName = "Coffee";
            drinkPrice = 2m;
        }
        else if (rdoJuice.Checked)
        {
            drinkName = "Juice";
            drinkPrice = 3m;
        }
        else
        {
            MessageBox.Show("Please select a drink type.", "Input Error",
                MessageBoxButtons.OK, MessageBoxIcon.Error);
            return;
        }

        lstOrder.Items.Clear();
        bool wonPrize = false;

        for (int i = 1; i <= quantity; i++)
        {
            int luckyNumber = random.Next(1, 51);
            lstOrder.Items.Add($"{i}) {customerName} - {drinkName} - Lucky: {luckyNumber} - ${drinkPrice:F2}");

            if (luckyNumber == 7 || luckyNumber == 17)
            {
                wonPrize = true;
            }
        }

        totalPrice = drinkPrice * quantity;

        if (chkStudentMember.Checked)
        {
            totalPrice *= 0.90m;
        }

        lblTotalPrice.Text = $"Total Price: ${totalPrice:F2}";
        lblLuckyMessage.Text = wonPrize
            ? "Lucky Message: You got a Free Cookie!"
            : "Lucky Message: No prize this time.";
    }

    private void btnSave_Click(object sender, EventArgs e)
    {
        if (lstOrder.Items.Count == 0)
        {
            MessageBox.Show("No order to save.", "Save Order",
                MessageBoxButtons.OK, MessageBoxIcon.Information);
            return;
        }

        using (StreamWriter writer = File.AppendText("orders.txt"))
        {
            foreach (var item in lstOrder.Items)
            {
                writer.WriteLine(item.ToString());
            }

            writer.WriteLine(lblTotalPrice.Text);
            writer.WriteLine(lblLuckyMessage.Text);
            writer.WriteLine("----------------------------------------");
        }

        MessageBox.Show("Order saved.", "Save Order",
            MessageBoxButtons.OK, MessageBoxIcon.Information);
    }

    private void btnLoad_Click(object sender, EventArgs e)
    {
        if (!File.Exists("orders.txt"))
        {
            MessageBox.Show("No file found.", "Load Orders",
                MessageBoxButtons.OK, MessageBoxIcon.Information);
            return;
        }

        lstOrder.Items.Clear();

        using (StreamReader reader = File.OpenText("orders.txt"))
        {
            while (!reader.EndOfStream)
            {
                string line = reader.ReadLine();
                if (line != null)
                {
                    lstOrder.Items.Add(line);
                }
            }
        }
    }

    private void btnClear_Click(object sender, EventArgs e)
    {
        txtCustomerName.Clear();
        txtQuantity.Clear();
        lstOrder.Items.Clear();
        lblTotalPrice.Text = "Total Price:";
        lblLuckyMessage.Text = "Lucky Message:";
        chkStudentMember.Checked = false;
        rdoTea.Checked = false;
        rdoCoffee.Checked = false;
        rdoJuice.Checked = false;
        totalPrice = 0m;
    }
}
